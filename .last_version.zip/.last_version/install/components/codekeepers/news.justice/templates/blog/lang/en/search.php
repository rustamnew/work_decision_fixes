<?
$MESS ['T_NEWS_DETAIL_BACK'] = "Back to the list";
?>