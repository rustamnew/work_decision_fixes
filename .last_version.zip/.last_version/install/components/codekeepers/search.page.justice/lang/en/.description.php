<?
$MESS ['SEARCH_SEARCH_PAGE_NAME'] = "Common search page";
$MESS ['SEARCH_SEARCH_PAGE_DESCRIPTION'] = "Page with the search form and a search result display";
$MESS ['SEARCH_SERVICE'] = "Search";
?>