<?
$MESS ['MAIN_MENU_ITEMS_NAME'] = "Menu";
$MESS ['MAIN_MENU_ITEMS_DESC'] = "Displays menu of selected type";
$MESS ['MAIN_NAVIGATION_SERVICE'] = "Navigation";
?>