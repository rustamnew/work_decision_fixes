<?
$MESS["SEARCH_TIP"] = "Search";
$MESS["TAGS_TIP"] = "Tag";
$MESS["SORT_TIP"] = "Select here the tag sort mode: by name or by views.";
$MESS["PAGE_ELEMENTS_TIP"] = "Specifies the count of tags in cloud.";
$MESS["PERIOD_TIP"] = "Specifies the number of recent days for which to select tags.";
$MESS["URL_SEARCH_TIP"] = "The search page path (rel. to the site root).";
$MESS["TAGS_INHERIT_TIP"] = "Specifies to narrow the search.";
$MESS["CHECK_DATES_TIP"] = "Specifies to search only the active (unexpired) documents.";
$MESS["arrFILTER_TIP"] = "Allows to narrow the search area. For example, you can specify to search only static files.";
$MESS["CACHE_TYPE_TIP"] = "<i>Auto</i>: the cache is valid during the time predefined in the cache settings;<br /><i>Cache</i>: always cache for the period specified in the next field;<br /><i>Do not cache</i>: no caching is performed.";
$MESS["CACHE_TIME_TIP"] = "Specify here the period of time during which the cache is valid.";
$MESS["arrFILTER_socialnetwork_user_TIP"] = "Show the ID of the user whose content should be included in the search.";
?>