<?
$MESS ['BSF_C_MODULE_NOT_INSTALLED'] = "Search module is not installed.";
?>