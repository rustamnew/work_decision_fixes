<?
$MESS ['CD_BSTC_NAME'] = "Tag cloud";
$MESS ['CD_BSTC_DESCRIPTION'] = "Displaying the keywords (tag cloud).";
$MESS ['CD_BSTC_SEARCH'] = "Search";
?>