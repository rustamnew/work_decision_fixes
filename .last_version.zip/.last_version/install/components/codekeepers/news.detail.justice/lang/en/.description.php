<?
$MESS ['T_IBLOCK_DESC_DETAIL'] = "News details";
$MESS ['T_IBLOCK_DESC_DETAIL_DESC'] = "Shows the news details";
$MESS ['T_IBLOCK_DESC_NEWS'] = "News";
?>
