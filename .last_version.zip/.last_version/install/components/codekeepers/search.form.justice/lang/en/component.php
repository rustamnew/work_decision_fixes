<?
$MESS['BSF_C_MODULE_NOT_INSTALLED']="Sorry, the search module is temporary unavailable.";
?>
