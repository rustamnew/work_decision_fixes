<?
$MESS ['PAGE_TIP'] = "Specifies the path name of the search page.";
?>