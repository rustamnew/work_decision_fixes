<?
$MESS ['MAIN_FEEDBACK_COMPONENT_NAME'] = "Feedback Form";
$MESS ['MAIN_FEEDBACK_COMPONENT_DESCR'] = "Creates a form to send e-mail messages.";
?>