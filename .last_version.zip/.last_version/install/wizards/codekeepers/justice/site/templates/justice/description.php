<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();

$arTemplate = Array(
	'NAME' => GetMessage('TEMPLATE_DESCRIPTION_NAME'),
	'DESCRIPTION' => GetMessage('TEMPLATE_DESCRIPTION_DESC')
);
?>