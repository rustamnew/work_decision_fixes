<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
$APPLICATION->SetPageProperty("image", SITE_TEMPLATE_PATH."/assets/images/header/06_header.jpg");
$APPLICATION->SetTitle("��������");
?>

<section class="flat-get-in-touch py-100" >
    <div class="container">
        <div class="wrap-get-in-touch">
            <div class="get-in-touch">
                <h2><?=$GLOBALS['global_info']['title1'];?></h2>

                <?$APPLICATION->IncludeComponent("codekeepers:main.feedback.justice", "feedback-form-contacts", Array(
                    "COMPONENT_TEMPLATE" => ".default",
                    "AJAX_MODE" => "Y",
                    "AJAX_OPTION_SHADOW" => "N",
                    "AJAX_OPTION_JUMP" => "N",
                    "AJAX_OPTION_HISTORY" => "N",
                    "USE_CAPTCHA" => "Y",
                    "OK_TEXT" => GetMessage("FORM_OK_TEXT"),	
                    "REQUIRED_FIELDS" => array(
                        0 => "NAME",
                        1 => "PHONE",
                        2 => "MESSAGE",
                    ),
                    "EVENT_MESSAGE_ID" => array(
                        0 => "#FORM_ID#"
                    ),
                    "SUBMIT_TEXT" => $GLOBALS['global_info']['text'],

                    "FORM_PAGE" => "��������",
                    "FORM_SECTION" => "-",
                    "FORM_TYPE" => "����� �� �������� ���������",
                    ),
                    false
                );?>
            </div>
            <div class="contact-info">
                <h2><?=$GLOBALS['global_info']['title2'];?></h2>

                <ul>
                <?if($GLOBALS['global_info']['contacts_phone_show']):?>
                    <li class="clearfix">
                        <div class="wrap-icon">
							<?$path = CFile::GetPath($GLOBALS['global_info']['icon_phone']);?>

							<?if (stristr($path, '.svg')):?>
								<?
								$img_file = $path;

								$svg = new SimpleXMLElement( file_get_contents( $_SERVER["DOCUMENT_ROOT"].$img_file));
								if($svg['id']){
									$img_grup = $img_file.'#'.$svg['id'];
								}

								$svg_file = file_get_contents( $_SERVER["DOCUMENT_ROOT"].$img_file);
								print_r($svg_file);?>
							<?else:?>
								<img src=<?=$path?>>
							<?endif;?>
                        </div>
                        <div class="wrap-info">
                            <h3><?=$GLOBALS['global_info']['title_phone'];?></h3>
                            <p class="top"><?=$GLOBALS['global_info']['contacts_phone1'];?></p>
                            <p class="bottom"><?=$GLOBALS['global_info']['contacts_phone2'];?></p>
                        </div>
                    </li>
                <?endif;?>

                <?if($GLOBALS['global_info']['contacts_email_show']):?>
                    <li class="clearfix">
                        <div class="wrap-icon">
							<?$path = CFile::GetPath($GLOBALS['global_info']['icon_email']);?>

							<?if (stristr($path, '.svg')):?>
								<?
								$img_file = $path;

								$svg = new SimpleXMLElement( file_get_contents( $_SERVER["DOCUMENT_ROOT"].$img_file));
								if($svg['id']){
									$img_grup = $img_file.'#'.$svg['id'];
								}

								$svg_file = file_get_contents( $_SERVER["DOCUMENT_ROOT"].$img_file);
								print_r($svg_file);?>
							<?else:?>
								<img src=<?=$path?>>
							<?endif;?>
                        </div>
                        <div class="wrap-info">
                            <h3><?=$GLOBALS['global_info']['title_email'];?></h3>
                            <p class="top"><?=$GLOBALS['global_info']['contacts_email1'];?></p>
                            <p class="bottom"><?=$GLOBALS['global_info']['contacts_email2'];?></p>
                        </div>
                    </li>
                <?endif;?>

                <?if($GLOBALS['global_info']['contacts_address_show']):?>
                    <li class="clearfix">
                        <div class="wrap-icon">
							<?$path = CFile::GetPath($GLOBALS['global_info']['icon_address']);?>

							<?if (stristr($path, '.svg')):?>
								<?
								$img_file = $path;

								$svg = new SimpleXMLElement( file_get_contents( $_SERVER["DOCUMENT_ROOT"].$img_file));
								if($svg['id']){
									$img_grup = $img_file.'#'.$svg['id'];
								}

								$svg_file = file_get_contents( $_SERVER["DOCUMENT_ROOT"].$img_file);
								print_r($svg_file);?>
							<?else:?>
								<img src=<?=$path?>>
							<?endif;?>
                        </div>
                        <div class="wrap-info">
                            <h3><?=$GLOBALS['global_info']['title_address'];?></h3>
                            <p class="top"><?=$GLOBALS['global_info']['contacts_address1'];?></p>
                            <p class="bottom"><?=$GLOBALS['global_info']['contacts_address2'];?></p>
                        </div>
                    </li>
                <?endif;?>
                </ul>
            </div>
        </div>
    </div>
</section>

<?
$useragent=$_SERVER['HTTP_USER_AGENT'];
$height = "500";
if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
$height = "400";
?>

<?$APPLICATION->IncludeComponent(
    "bitrix:map.yandex.view",
    "",
    Array(
        "API_KEY" => "",
        "CONTROLS" => array(

        ),
        "INIT_MAP_TYPE" => "MAP",
        "MAP_DATA" => "a:3:{s:10:\"yandex_lat\";s:7:\"55.7383\";s:10:\"yandex_lon\";s:7:\"37.5946\";s:12:\"yandex_scale\";i:10;}",
        "MAP_HEIGHT" => $height,
        "MAP_ID" => "",
        "MAP_WIDTH" => "100%",
        "OPTIONS" => array(
			0 => "ENABLE_SCROLL_ZOOM",
			1 => "ENABLE_DBLCLICK_ZOOM",
			2 => "ENABLE_RIGHT_MAGNIFIER",
			3 => "ENABLE_DRAGGING",
        )
    )
);?>
<? require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php"); ?>