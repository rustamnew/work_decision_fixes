<?
$arModuleVersion = array(
	"VERSION" => "1.0.21",
	"VERSION_DATE" => "2021-12-30 13:00:00"
);
?>