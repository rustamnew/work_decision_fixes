<?
$arModuleVersion = array(
	"VERSION" => "1.0.37",
	"VERSION_DATE" => "2022-01-14 23:01:06"
);
?>